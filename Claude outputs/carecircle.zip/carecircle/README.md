# CareCircle

**Amma sees one screen. The family sees everything.**

CareCircle is a medication and appointment platform for elders, their caretakers and their families.
Built for the PromptWars x Catalyst hackathon by Makers Need More (MnM).

## The problem

Lakshmi, 76, lives alone in Chennai and takes six tablets a day. Her son lives in Bengaluru and calls two or three times a day to ask "did you take it?". Her answer depends on her memory. Reminder apps assume she will set them up herself, alert the family about every dose until they stop reading, and show drug names she doesn't recognise.

## What CareCircle does

| Feature | What it solves |
|---|---|
| **Two interfaces** | Family and caretakers get a full dashboard. The elder gets one large, high-contrast screen with no login, showing only *"what do I take right now?"*, with **I took it / Remind me in 15 min / Not today**. |
| **Visual pill cards** | Medicines are shown as the pill looks (colour, shape, size) with a plain sentence: *"Take one small round white tablet after food."* |
| **Two-stage escalation** | First stage: the prompt on the elder's screen plus an "upcoming dose" email. Second stage: if the dose is still unconfirmed 30 minutes later, the caretakers get an email with a **Mark as given** button. Critical medicines go to the whole circle after 60 minutes. Supplements never escalate. Snoozing pushes the timer back. Once anyone confirms the dose, nobody else is alerted. |
| **Doctor visit sheet** | Each appointment has a printable sheet: current medicines, 30-day adherence per medicine, missed or skipped doses **with the elder's own reasons**, and questions for the doctor. The reminder email the day before links to it. |
| **Refill countdown** | Stock goes down with every confirmed dose. At 5 days or fewer, the family and caretakers get an email. |
| **Shared, passcode-based access** | A circle code plus a 6-digit passcode, with roles for elder, caretaker and family. An activity log shows who did what. |

Doses are entered the way Indian prescriptions are written (**1-0-1, after food**). The app works out the times.

## Architecture

```
 Elder phone ─ /e/[token] (no login) ─┐
 Family/caretaker ─ /dashboard ───────┼─▶ Next.js (Cloud Run or Vercel) ─▶ Supabase Postgres
 Email button ─ /a/[token] (POST) ────┘          ▲                 └────▶ Gmail SMTP (Nodemailer)
                     Cloud Scheduler / cron-job.org ─ every 5 min ─▶ /api/cron/tick
```

- The `dose_events` table, with `unique(med_id, due_at)`, also acts as the job queue, so running the reminder job twice is harmless.
- Each email is "claimed" with a conditional update before it is sent, so overlapping runs never send the same email twice.
- Email links open a confirmation page. Nothing is recorded until a person presses the button, so email scanners that open links automatically can't log a dose.

## Setup (about 15 minutes)

1. **Supabase**: create a project, open the SQL Editor, paste `schema.sql` and run it. Copy the URL and the service role key.
2. **Gmail**: turn on 2-Step Verification and create an App Password.
3. `cp .env.example .env.local`, fill in the values, then `npm install && npm run dev`.
4. **Deploy**
   - **Cloud Run**: `gcloud run deploy carecircle --source . --region asia-south1 --allow-unauthenticated --set-env-vars ...`
     Then: `gcloud scheduler jobs create http carecircle-tick --schedule="*/5 * * * *" --uri=https://YOUR-URL/api/cron/tick --http-method=POST --headers=x-cron-secret=YOUR_CRON_SECRET --location=asia-south1`
   - **Vercel**: import the repo and add the env vars. Vercel's free cron runs only once a day, so create a job on **cron-job.org** that calls `https://YOUR-URL/api/cron/tick?secret=YOUR_CRON_SECRET` every 5 minutes.
5. Set `BASE_URL` to the live URL so email links work.

## Known limitations
- Passcode access is hackathon-grade, and attempts are not rate-limited.
- Reminders can run up to 5 minutes late.
- A tap does not prove the pill was swallowed.
- Email only: SMS in India needs DLT registration.
- Times are Indian Standard Time.

## Next steps
WhatsApp and SMS alerts · Tamil and Hindi voice prompts · syncing prescriptions with ABDM/FHIR · proper login for family members.
