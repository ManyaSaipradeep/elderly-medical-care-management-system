import 'server-only';
import { db, ensureDoses, sendMail, emailShell, button, makeToken, BASE_URL, fmtTime, fmtDateTime, plainInstruction, daysLeft, istDate, SLOT_LABEL, type Med } from './core';

const MIN = 60_000;
type Member = { id: string; name: string; email: string | null; role: string };

/** Claim a notification level atomically so overlapping runs never double-send. */
async function claim(id: string, level: number) {
  const { data } = await db.from('dose_events').update({ notified_level: level }).eq('id', id).lt('notified_level', level).eq('status', 'pending').select('id');
  return !!data?.length;
}
const actionLinks = (doseId: string, m: Member) =>
  button(`${BASE_URL}/a/${makeToken({ d: doseId, m: m.id, a: 'taken' })}`, '✅ Mark as given') +
  button(`${BASE_URL}/a/${makeToken({ d: doseId, m: m.id, a: 'skipped' })}`, 'Skipped today', '#6b7280');

/** The escalation engine. Safe to run any number of times. */
export async function runTick() {
  const now = Date.now();
  const log: string[] = [];
  await ensureDoses();

  const { data: members } = await db.from('members').select('*');
  const { data: circles } = await db.from('circles').select('id, elder_name, elder_token');
  const byCircle = (cid: string) => ((members || []) as (Member & { circle_id: string })[]).filter((m) => m.circle_id === cid && m.email);
  const circle = (cid: string) => (circles || []).find((c) => c.id === cid)!;

  // Doses from the last 4 hours to the next 15 minutes that are still open
  const { data: doses } = await db.from('dose_events').select('*, medications(*)')
    .eq('status', 'pending').gte('due_at', new Date(now - 4 * 60 * MIN).toISOString()).lte('due_at', new Date(now + 15 * MIN).toISOString());

  for (const d of doses || []) {
    const med = d.medications as Med;
    const c = circle(d.circle_id);
    const ms = byCircle(d.circle_id);
    const elders = ms.filter((m) => m.role === 'elder');
    const carers = ms.filter((m) => m.role === 'caretaker');
    const family = ms.filter((m) => m.role === 'family');
    const due = new Date(d.due_at).getTime();
    // Snoozing moves the clock: lateness counts from the end of the snooze
    const ref = Math.max(due, d.snoozed_until ? new Date(d.snoozed_until).getTime() : 0);
    const late = (now - ref) / MIN;
    const what = `${med.name} — ${plainInstruction(med, d.qty)}`;

    // Stage 0: upcoming dose (15 min before) → elder if they have email, else caretakers
    if (d.notified_level < 1 && now >= due - 15 * MIN && await claim(d.id, 1)) {
      const to = elders.length ? elders : carers.length ? carers : family;
      for (const m of to) await sendMail([m.email!], `Coming up at ${fmtTime(d.due_at)}: ${med.name}`,
        emailShell(`${SLOT_LABEL[d.slot]} medicine for ${c.elder_name}`, `<p>${what}</p><p><a href="${BASE_URL}/e/${c.elder_token}">Open ${c.elder_name}'s screen</a></p>${actionLinks(d.id, m)}`));
      log.push(`upcoming:${med.name}`);
    }
    if (med.criticality === 'supplement') { if (late >= 180) await db.from('dose_events').update({ status: 'missed' }).eq('id', d.id).eq('status', 'pending'); continue; }

    // Stage 1: 30 min unconfirmed → caretakers (family if no caretaker)
    if (late >= 30 && d.notified_level < 2 && await claim(d.id, 2)) {
      const to = carers.length ? carers : family;
      for (const m of to) await sendMail([m.email!], `Not yet confirmed: ${c.elder_name}'s ${med.name}`,
        emailShell(`${c.elder_name}'s ${SLOT_LABEL[d.slot].toLowerCase()} dose isn't confirmed`, `<p>Due at <b>${fmtTime(d.due_at)}</b>: ${what}</p><p>If you gave it, tap below. Nobody else will be alerted.</p>${actionLinks(d.id, m)}`));
      log.push(`stage1:${med.name}`);
    }
    // Stage 2: 60 min unconfirmed and critical → whole circle
    if (med.criticality === 'critical' && late >= 60 && d.notified_level < 3 && await claim(d.id, 3)) {
      for (const m of ms) await sendMail([m.email!], `⚠️ Critical dose missed: ${c.elder_name}'s ${med.name}`,
        emailShell(`Critical medicine still not taken`, `<p><b>${med.name}</b> was due at <b>${fmtTime(d.due_at)}</b> and nobody has confirmed it for an hour. Please call ${c.elder_name}.</p>${actionLinks(d.id, m)}`));
      log.push(`stage2:${med.name}`);
    }
    if (late >= 180) await db.from('dose_events').update({ status: 'missed' }).eq('id', d.id).eq('status', 'pending');
  }

  // Appointments in the next 24h → everyone, with the doctor visit sheet
  const { data: appts } = await db.from('appointments').select('*').eq('reminded', false)
    .gte('at', new Date(now).toISOString()).lte('at', new Date(now + 24 * 60 * MIN).toISOString());
  for (const a of appts || []) {
    const { data: ok } = await db.from('appointments').update({ reminded: true }).eq('id', a.id).eq('reminded', false).select('id');
    if (!ok?.length) continue;
    const c = circle(a.circle_id);
    await sendMail(byCircle(a.circle_id).map((m) => m.email!), `Tomorrow: ${c.elder_name} sees ${a.doctor}`,
      emailShell(`${a.doctor} · ${fmtDateTime(a.at)}`, `<p>${a.location ? a.location + '<br>' : ''}The visit sheet is ready: current medicines, 30-day adherence, and missed or skipped doses with reasons.</p>${button(`${BASE_URL}/visit/${a.id}`, '📋 Open visit sheet')}`));
    log.push(`appt:${a.doctor}`);
  }

  // Refill countdown → caretakers + family, once per day per medicine
  const today = istDate();
  const { data: meds } = await db.from('medications').select('*').eq('active', true);
  for (const m of (meds || []) as Med[]) {
    const left = daysLeft(m);
    if (left > 5 || m.refill_alerted_on === today) continue;
    await db.from('medications').update({ refill_alerted_on: today }).eq('id', m.id);
    const c = circle(m.circle_id);
    await sendMail(byCircle(m.circle_id).filter((x) => x.role !== 'elder').map((x) => x.email!), `Refill needed: ${m.name} (${left} days left)`,
      emailShell(`Time to refill ${m.name}`, `<p>${c.elder_name} has <b>${m.stock}</b> left — about <b>${left} day${left === 1 ? '' : 's'}</b> at the current dose.</p>`));
    log.push(`refill:${m.name}`);
  }
  return log;
}
