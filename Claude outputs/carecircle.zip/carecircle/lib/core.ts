import 'server-only';
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import { cookies } from 'next/headers';

// ---------- Database (server only, service role key) ----------
export const db = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false },
});

const SECRET = process.env.APP_SECRET || 'dev-secret-change-me';
export const BASE_URL = (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');

// ---------- Crypto helpers ----------
export const hashPasscode = (code: string, salt: string) =>
  crypto.createHash('sha256').update(`${salt}:${code}:${SECRET}`).digest('hex');
export const randomCode = (n: number, alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789') =>
  Array.from(crypto.randomBytes(n)).map((b) => alphabet[b % alphabet.length]).join('');
const sign = (data: string) => crypto.createHmac('sha256', SECRET).update(data).digest('base64url');

/** Signed token: base64url(payload).signature */
export function makeToken(payload: object) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return `${body}.${sign(body)}`;
}
export function readToken<T>(token: string): T | null {
  const [body, sig] = (token || '').split('.');
  if (!body || !sig) return null;
  const expected = sign(body);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try { return JSON.parse(Buffer.from(body, 'base64url').toString()); } catch { return null; }
}

// ---------- Session ----------
export type Session = { memberId: string; circleId: string; name: string; role: string };
export async function getSession(): Promise<Session | null> {
  const c = (await cookies()).get('cc_session');
  return c ? readToken<Session>(c.value) : null;
}
export async function setSession(s: Session) {
  (await cookies()).set('cc_session', makeToken(s), { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 60, secure: process.env.NODE_ENV === 'production' });
}

// ---------- Time (India, fixed +05:30) ----------
export const TZ = 'Asia/Kolkata';
export const istDate = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(d); // YYYY-MM-DD
export const atIST = (date: string, hhmm: string) => new Date(`${date}T${hhmm}:00+05:30`);
export const fmtTime = (d: string | Date) => new Date(d).toLocaleTimeString('en-IN', { timeZone: TZ, hour: 'numeric', minute: '2-digit' });
export const fmtDateTime = (d: string | Date) => new Date(d).toLocaleString('en-IN', { timeZone: TZ, weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });

// ---------- Medication helpers ----------
export const SLOTS = ['morning', 'afternoon', 'night'] as const;
export const SLOT_LABEL: Record<string, string> = { morning: 'Morning', afternoon: 'Afternoon', night: 'Night' };
export type Med = {
  id: string; circle_id: string; name: string; pattern: string; slot_times: Record<string, string>; food: string;
  criticality: 'critical' | 'normal' | 'supplement'; pill_color: string; pill_shape: string; pill_size: string;
  stock: number; refill_alerted_on: string | null; active: boolean;
};
export const patternCounts = (p: string) => (p.split('-').map((x) => parseInt(x, 10) || 0).concat([0, 0, 0])).slice(0, 3);
export const perDay = (m: Med) => patternCounts(m.pattern).reduce((a, b) => a + b, 0);
export const daysLeft = (m: Med) => (perDay(m) ? Math.floor(m.stock / perDay(m)) : Infinity);
export function plainInstruction(m: Pick<Med, 'pill_size' | 'pill_color' | 'pill_shape' | 'food'>, qty: number) {
  const form = m.pill_shape === 'capsule' ? 'capsule' : 'tablet';
  const shape = m.pill_shape === 'capsule' ? '' : `${m.pill_shape} `;
  const n = qty === 1 ? 'one' : qty === 2 ? 'two' : String(qty);
  return `Take ${n} ${m.pill_size} ${shape}${m.pill_color} ${form}${qty > 1 ? 's' : ''}${m.food === 'any time' ? '' : ' ' + m.food}.`;
}

/** Create today's (and tomorrow's) dose rows. Safe to run repeatedly thanks to unique(med_id, due_at). */
export async function ensureDoses(circleId?: string) {
  let q = db.from('medications').select('*').eq('active', true);
  if (circleId) q = q.eq('circle_id', circleId);
  const { data: meds } = await q;
  const today = istDate();
  const tomorrow = istDate(new Date(Date.now() + 86400000));
  const rows: any[] = [];
  for (const m of (meds || []) as Med[]) {
    const counts = patternCounts(m.pattern);
    SLOTS.forEach((slot, i) => {
      if (!counts[i]) return;
      for (const d of [today, tomorrow]) {
        rows.push({ med_id: m.id, circle_id: m.circle_id, slot, qty: counts[i], due_at: atIST(d, m.slot_times?.[slot] || '08:00').toISOString() });
      }
    });
  }
  if (rows.length) await db.from('dose_events').upsert(rows, { onConflict: 'med_id,due_at', ignoreDuplicates: true });
}

export async function logActivity(circleId: string, actor: string, action: string) {
  await db.from('activity').insert({ circle_id: circleId, actor, action });
}

/** Mark a dose. Only changes a dose that is still pending (first person wins). */
export async function actOnDose(doseId: string, status: 'taken' | 'skipped', actor: string, reason?: string) {
  const { data } = await db.from('dose_events')
    .update({ status, acted_by: actor, acted_at: new Date().toISOString(), reason: reason || null })
    .eq('id', doseId).in('status', ['pending', 'missed']).select('*, medications(name, stock, circle_id)').maybeSingle();
  if (!data) return null;
  if (status === 'taken') {
    await db.from('medications').update({ stock: Math.max(0, (data.medications.stock || 0) - data.qty) }).eq('id', data.med_id);
  }
  await logActivity(data.circle_id, actor, `${status === 'taken' ? 'Marked taken' : 'Skipped'}: ${data.medications.name} (${SLOT_LABEL[data.slot]})${reason ? ' — ' + reason : ''}`);
  return data;
}

export async function undoDose(doseId: string, actor: string) {
  const { data } = await db.from('dose_events').select('*, medications(name, stock)').eq('id', doseId).maybeSingle();
  if (!data || data.status === 'pending') return;
  if (data.acted_at && Date.now() - new Date(data.acted_at).getTime() > 10 * 60 * 1000) return; // 10-min undo window
  if (data.status === 'taken') await db.from('medications').update({ stock: (data.medications.stock || 0) + data.qty }).eq('id', data.med_id);
  await db.from('dose_events').update({ status: 'pending', acted_by: null, acted_at: null, reason: null }).eq('id', doseId);
  await logActivity(data.circle_id, actor, `Undid: ${data.medications.name} (${SLOT_LABEL[data.slot]})`);
}

/** 30-day adherence for a circle: taken / (all doses already due). */
export async function adherence(circleId: string, days = 30) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const { data } = await db.from('dose_events').select('status, due_at, med_id').eq('circle_id', circleId)
    .gte('due_at', since).lte('due_at', new Date().toISOString());
  const rows = data || [];
  const done = rows.filter((r) => r.status !== 'pending');
  const taken = rows.filter((r) => r.status === 'taken').length;
  return { rows, pct: done.length ? Math.round((taken / done.length) * 100) : null, taken, total: done.length };
}

// ---------- Email ----------
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD },
});
export async function sendMail(to: string[], subject: string, html: string) {
  const list = [...new Set(to.filter(Boolean))];
  if (!list.length) return false;
  if (!process.env.GMAIL_USER) { console.log('[mail:dry-run]', list, subject); return true; }
  await transporter.sendMail({ from: `CareCircle <${process.env.GMAIL_USER}>`, to: list.join(','), subject, html });
  return true;
}
export const emailShell = (title: string, body: string) => `
<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;font-size:16px;color:#1f2937">
  <h2 style="color:#0f766e;margin-bottom:8px">${title}</h2>${body}
  <p style="color:#6b7280;font-size:13px;margin-top:24px">Sent by CareCircle · you are in this care circle.</p>
</div>`;
export const button = (href: string, label: string, color = '#0f766e') =>
  `<a href="${href}" style="display:inline-block;background:${color};color:#fff;padding:14px 22px;border-radius:10px;text-decoration:none;font-weight:bold;margin:6px 6px 0 0">${label}</a>`;
