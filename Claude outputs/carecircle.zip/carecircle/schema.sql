-- CareCircle schema. Paste into Supabase > SQL Editor > Run.
create extension if not exists pgcrypto;

create table circles (
  id uuid primary key default gen_random_uuid(),
  elder_name text not null,
  circle_code text unique not null,
  passcode_hash text not null,
  elder_token text unique not null,
  created_at timestamptz default now()
);

create table members (
  id uuid primary key default gen_random_uuid(),
  circle_id uuid references circles(id) on delete cascade,
  name text not null,
  email text,
  role text not null check (role in ('elder','caretaker','family')),
  created_at timestamptz default now()
);

create table medications (
  id uuid primary key default gen_random_uuid(),
  circle_id uuid references circles(id) on delete cascade,
  name text not null,
  pattern text not null default '1-0-1',          -- morning-afternoon-night counts
  slot_times jsonb not null default '{"morning":"08:00","afternoon":"13:00","night":"21:00"}',
  food text not null default 'after food',        -- before food | after food | with food | any time
  criticality text not null default 'normal' check (criticality in ('critical','normal','supplement')),
  pill_color text not null default 'white',
  pill_shape text not null default 'round',       -- round | oval | capsule
  pill_size text not null default 'small',        -- small | large
  stock int not null default 30,
  refill_alerted_on date,
  active boolean not null default true,
  created_at timestamptz default now()
);

create table dose_events (
  id uuid primary key default gen_random_uuid(),
  med_id uuid references medications(id) on delete cascade,
  circle_id uuid references circles(id) on delete cascade,
  slot text not null,
  qty int not null default 1,
  due_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending','taken','skipped','missed')),
  reason text,
  acted_by text,
  acted_at timestamptz,
  snoozed_until timestamptz,
  notified_level int not null default 0,
  unique (med_id, due_at)
);
create index on dose_events (status, due_at);

create table appointments (
  id uuid primary key default gen_random_uuid(),
  circle_id uuid references circles(id) on delete cascade,
  doctor text not null,
  location text,
  at timestamptz not null,
  notes text,
  reminded boolean not null default false
);

create table activity (
  id bigserial primary key,
  circle_id uuid references circles(id) on delete cascade,
  actor text not null,
  action text not null,
  at timestamptz default now()
);
