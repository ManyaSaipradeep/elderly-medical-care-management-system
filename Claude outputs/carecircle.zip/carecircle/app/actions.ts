'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { cookies } from 'next/headers';
import { db, getSession, setSession, hashPasscode, randomCode, logActivity, actOnDose, undoDose, readToken, ensureDoses } from '@/lib/core';

const str = (f: FormData, k: string) => String(f.get(k) || '').trim();

async function requireSession() {
  const s = await getSession();
  if (!s) redirect('/');
  return s;
}

export async function createCircle(f: FormData) {
  const elder = str(f, 'elder_name'), name = str(f, 'name'), email = str(f, 'email'), role = str(f, 'role') || 'family';
  const passcode = str(f, 'passcode');
  if (!elder || !name || !/^\d{6}$/.test(passcode)) redirect('/?error=Enter names and a 6-digit passcode');
  const code = randomCode(6);
  const { data: circle, error } = await db.from('circles').insert({
    elder_name: elder, circle_code: code, passcode_hash: hashPasscode(passcode, code), elder_token: randomCode(24, 'abcdefghijkmnpqrstuvwxyz23456789'),
  }).select().single();
  if (error) redirect('/?error=' + encodeURIComponent(error.message));
  const { data: m } = await db.from('members').insert({ circle_id: circle.id, name, email: email || null, role }).select().single();
  await logActivity(circle.id, name, `Created the care circle for ${elder}`);
  await setSession({ memberId: m!.id, circleId: circle.id, name, role });
  redirect('/dashboard?new=1');
}

export async function joinCircle(f: FormData) {
  const code = str(f, 'circle_code').toUpperCase(), passcode = str(f, 'passcode');
  const name = str(f, 'name'), email = str(f, 'email'), role = str(f, 'role') || 'family';
  const { data: circle } = await db.from('circles').select('*').eq('circle_code', code).maybeSingle();
  if (!circle || circle.passcode_hash !== hashPasscode(passcode, code)) redirect('/?error=Circle code or passcode is wrong&tab=join');
  if (!name) redirect('/?error=Please enter your name&tab=join');
  const { data: m } = await db.from('members').insert({ circle_id: circle.id, name, email: email || null, role }).select().single();
  await logActivity(circle.id, name, `Joined as ${role}`);
  await setSession({ memberId: m!.id, circleId: circle.id, name, role });
  redirect('/dashboard');
}

export async function logout() {
  (await cookies()).delete('cc_session');
  redirect('/');
}

function medFields(f: FormData) {
  const p = [str(f, 'p_m') || '0', str(f, 'p_a') || '0', str(f, 'p_n') || '0'].join('-');
  return {
    name: str(f, 'name'), pattern: p, food: str(f, 'food') || 'after food', criticality: str(f, 'criticality') || 'normal',
    pill_color: str(f, 'pill_color') || 'white', pill_shape: str(f, 'pill_shape') || 'round', pill_size: str(f, 'pill_size') || 'small',
    stock: parseInt(str(f, 'stock') || '0', 10) || 0,
    slot_times: { morning: str(f, 't_m') || '08:00', afternoon: str(f, 't_a') || '13:00', night: str(f, 't_n') || '21:00' },
  };
}

export async function saveMed(f: FormData) {
  const s = await requireSession();
  const id = str(f, 'id');
  const fields = medFields(f);
  if (!fields.name) return;
  if (id) {
    await db.from('medications').update({ ...fields, refill_alerted_on: null }).eq('id', id).eq('circle_id', s.circleId);
    // Future pending doses are regenerated with the new schedule
    await db.from('dose_events').delete().eq('med_id', id).eq('status', 'pending').gt('due_at', new Date().toISOString());
    await logActivity(s.circleId, s.name, `Edited medicine: ${fields.name} (${fields.pattern})`);
  } else {
    await db.from('medications').insert({ ...fields, circle_id: s.circleId });
    await logActivity(s.circleId, s.name, `Added medicine: ${fields.name} (${fields.pattern}, ${fields.food})`);
  }
  await ensureDoses(s.circleId);
  revalidatePath('/dashboard');
  redirect('/dashboard#meds');
}

export async function stopMed(f: FormData) {
  const s = await requireSession();
  const { data } = await db.from('medications').update({ active: false }).eq('id', str(f, 'id')).eq('circle_id', s.circleId).select().single();
  await db.from('dose_events').delete().eq('med_id', str(f, 'id')).eq('status', 'pending').gt('due_at', new Date().toISOString());
  if (data) await logActivity(s.circleId, s.name, `Stopped medicine: ${data.name}`);
  revalidatePath('/dashboard');
}

export async function refill(f: FormData) {
  const s = await requireSession();
  const add = parseInt(str(f, 'add'), 10) || 0;
  const { data } = await db.from('medications').select('*').eq('id', str(f, 'id')).eq('circle_id', s.circleId).single();
  if (!data || add <= 0) return;
  await db.from('medications').update({ stock: data.stock + add, refill_alerted_on: null }).eq('id', data.id);
  await logActivity(s.circleId, s.name, `Refilled ${data.name}: +${add}`);
  revalidatePath('/dashboard');
}

export async function saveAppt(f: FormData) {
  const s = await requireSession();
  const date = str(f, 'date'), time = str(f, 'time') || '10:00';
  if (!str(f, 'doctor') || !date) return;
  await db.from('appointments').insert({
    circle_id: s.circleId, doctor: str(f, 'doctor'), location: str(f, 'location') || null, notes: str(f, 'notes') || null,
    at: new Date(`${date}T${time}:00+05:30`).toISOString(),
  });
  await logActivity(s.circleId, s.name, `Added appointment: ${str(f, 'doctor')} on ${date}`);
  revalidatePath('/dashboard');
}

export async function saveApptNotes(f: FormData) {
  const s = await requireSession();
  await db.from('appointments').update({ notes: str(f, 'notes') }).eq('id', str(f, 'id')).eq('circle_id', s.circleId);
  revalidatePath(`/visit/${str(f, 'id')}`);
}

export async function deleteAppt(f: FormData) {
  const s = await requireSession();
  await db.from('appointments').delete().eq('id', str(f, 'id')).eq('circle_id', s.circleId);
  revalidatePath('/dashboard');
}

// ---------- Dose actions (dashboard) ----------
export async function dashDose(f: FormData) {
  const s = await requireSession();
  const id = str(f, 'id');
  const { data } = await db.from('dose_events').select('circle_id').eq('id', id).single();
  if (data?.circle_id !== s.circleId) return;
  const act = str(f, 'act');
  if (act === 'undo') await undoDose(id, s.name);
  else await actOnDose(id, act as 'taken' | 'skipped', `${s.name} (${s.role})`, str(f, 'reason'));
  revalidatePath('/dashboard');
}

// ---------- Elder kiosk actions (authorised by elder token, no login) ----------
async function circleByToken(token: string) {
  const { data } = await db.from('circles').select('*').eq('elder_token', token).maybeSingle();
  return data;
}
export async function kioskAct(token: string, doseId: string, act: 'taken' | 'skipped' | 'snooze' | 'undo', reason?: string) {
  const circle = await circleByToken(token);
  if (!circle) return;
  const { data: dose } = await db.from('dose_events').select('circle_id').eq('id', doseId).single();
  if (dose?.circle_id !== circle.id) return;
  const who = circle.elder_name;
  if (act === 'snooze') {
    await db.from('dose_events').update({ snoozed_until: new Date(Date.now() + 15 * 60000).toISOString() }).eq('id', doseId).eq('status', 'pending');
    await logActivity(circle.id, who, 'Snoozed a dose for 15 minutes');
  } else if (act === 'undo') await undoDose(doseId, who);
  else await actOnDose(doseId, act, who, reason);
  revalidatePath(`/e/${token}`);
}

export async function kioskHelp(token: string) {
  const circle = await circleByToken(token);
  if (!circle) return;
  const { sendMail, emailShell } = await import('@/lib/core');
  const { data: members } = await db.from('members').select('email').eq('circle_id', circle.id);
  await sendMail((members || []).map((m) => m.email), `${circle.elder_name} is asking for help`,
    emailShell(`${circle.elder_name} pressed “Call my family”`, `<p>Please call ${circle.elder_name} as soon as you can.</p>`));
  await logActivity(circle.id, circle.elder_name, 'Pressed “Call my family”');
}

// ---------- Email one-tap actions (signed token, confirmed by POST) ----------
export async function emailAct(f: FormData) {
  const t = readToken<{ d: string; m: string; a: 'taken' | 'skipped' }>(str(f, 'token'));
  if (!t) redirect('/');
  const { data: m } = await db.from('members').select('name, role').eq('id', t.m).single();
  const res = await actOnDose(t.d, t.a, m ? `${m.name} (${m.role}, via email)` : 'Email link');
  redirect(`/a/done?ok=${res ? 1 : 0}`);
}

export async function runRemindersNow() {
  const s = await requireSession();
  const { runTick } = await import('@/lib/tick');
  const sent = await runTick();
  await logActivity(s.circleId, s.name, `Ran reminders now (${sent.length} sent)`);
  revalidatePath('/dashboard');
}
