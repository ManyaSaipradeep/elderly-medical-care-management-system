import { redirect } from 'next/navigation';
import { db, getSession, ensureDoses, adherence, istDate, fmtTime, fmtDateTime, plainInstruction, daysLeft, perDay, SLOT_LABEL, BASE_URL, type Med } from '@/lib/core';
import { logout, dashDose, stopMed, refill, saveAppt, deleteAppt, runRemindersNow } from '../actions';
import Pill from '@/components/Pill';
import MedForm from '@/components/MedForm';

export const dynamic = 'force-dynamic';

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ new?: string }> }) {
  const s = await getSession();
  if (!s) redirect('/');
  const { new: isNew } = await searchParams;
  await ensureDoses(s.circleId);

  const today = istDate();
  const dayStart = new Date(`${today}T00:00:00+05:30`), dayEnd = new Date(dayStart.getTime() + 86400000);
  const [{ data: circle }, { data: meds }, { data: doses }, { data: appts }, { data: acts }, { data: members }, adh] = await Promise.all([
    db.from('circles').select('*').eq('id', s.circleId).single(),
    db.from('medications').select('*').eq('circle_id', s.circleId).eq('active', true).order('created_at'),
    db.from('dose_events').select('*, medications(*)').eq('circle_id', s.circleId).gte('due_at', dayStart.toISOString()).lt('due_at', dayEnd.toISOString()).order('due_at'),
    db.from('appointments').select('*').eq('circle_id', s.circleId).gte('at', new Date(Date.now() - 86400000).toISOString()).order('at'),
    db.from('activity').select('*').eq('circle_id', s.circleId).order('at', { ascending: false }).limit(15),
    db.from('members').select('*').eq('circle_id', s.circleId).order('created_at'),
    adherence(s.circleId, 30),
  ]);
  if (!circle) redirect('/');
  const elderUrl = `${BASE_URL}/e/${circle.elder_token}`;
  const now = Date.now();
  const lowStock = ((meds || []) as Med[]).filter((m) => daysLeft(m) <= 5);
  const overdue = (doses || []).filter((d) => d.status === 'pending' && new Date(d.due_at).getTime() < now - 30 * 60000);

  // 7-day grid: per medicine, per day → status summary
  const days = Array.from({ length: 7 }, (_, i) => istDate(new Date(now - (6 - i) * 86400000)));
  const cell = (medId: string, day: string) => {
    const rs = adh.rows.filter((r) => r.med_id === medId && istDate(new Date(r.due_at)) === day);
    if (!rs.length) return { c: '#f1f5f9', t: '—' };
    if (rs.some((r) => r.status === 'missed')) return { c: '#fecaca', t: 'missed' };
    if (rs.some((r) => r.status === 'skipped')) return { c: '#fde68a', t: 'skipped' };
    if (rs.every((r) => r.status === 'taken')) return { c: '#86efac', t: 'all taken' };
    return { c: '#e2e8f0', t: 'pending' };
  };

  return (
    <main className="wrap">
      <div className="top">
        <a className="brand" href="/dashboard">CareCircle</a>
        <div className="row">
          <span className="muted">{s.name} · {s.role}</span>
          <form action={logout}><button className="ghost small">Log out</button></form>
        </div>
      </div>

      <h1>{circle.elder_name}'s care circle</h1>
      {isNew && <div className="alert ok">Circle created. Share the circle code <b>{circle.circle_code}</b> and your passcode with family and caretakers.</div>}
      {overdue.map((d) => <div key={d.id} className="alert bad">Not yet confirmed: {d.medications.name} ({SLOT_LABEL[d.slot]}, due {fmtTime(d.due_at)})</div>)}
      {lowStock.map((m) => <div key={m.id} className="alert warn">Refill soon: {m.name} — {m.stock} left (~{daysLeft(m)} days)</div>)}

      <div className="grid">
        <section className="card">
          <h2>{circle.elder_name}'s simple screen</h2>
          <p>Open this link on {circle.elder_name}'s phone and choose <b>Add to Home screen</b>. No login, one big button.</p>
          <p><a className="btn" href={elderUrl} target="_blank">Open {circle.elder_name}'s screen</a></p>
          <p className="muted" style={{ wordBreak: 'break-all' }}>{elderUrl}</p>
          <p className="muted">Circle code: <b>{circle.circle_code}</b> · Members: {(members || []).map((m) => `${m.name} (${m.role})`).join(', ')}</p>
        </section>
        <section className="card">
          <h2>Adherence, last 30 days</h2>
          <p style={{ fontSize: '2.4rem', fontWeight: 800, margin: 0, color: adh.pct === null ? '#6b7280' : adh.pct >= 80 ? '#15803d' : adh.pct >= 60 ? '#b45309' : '#b91c1c' }}>
            {adh.pct === null ? '—' : `${adh.pct}%`}
          </p>
          <p className="muted">{adh.taken} of {adh.total} due doses confirmed taken.</p>
          <form action={runRemindersNow}><button className="ghost small">Run reminders now</button></form>
          <p className="muted">Reminders also run automatically every 5 minutes.</p>
        </section>
      </div>

      <section className="card">
        <h2>Today</h2>
        {!(doses || []).length && <p className="muted">No doses today. Add a medicine below.</p>}
        <table><tbody>
          {(doses || []).map((d) => (
            <tr key={d.id}>
              <td style={{ width: 90 }}><b>{fmtTime(d.due_at)}</b><div className="muted">{SLOT_LABEL[d.slot]}</div></td>
              <td style={{ width: 70 }}><Pill color={d.medications.pill_color} shape={d.medications.pill_shape} size={d.medications.pill_size} scale={0.6} /></td>
              <td>{d.medications.name} <span className={`tag ${d.medications.criticality}`}>{d.medications.criticality}</span><div className="muted">{plainInstruction(d.medications, d.qty)}</div></td>
              <td>
                <span className={`tag ${d.status}`}>{d.status}</span>
                {d.acted_by && <div className="muted">by {d.acted_by}{d.acted_at ? ` at ${fmtTime(d.acted_at)}` : ''}</div>}
                {d.reason && <div className="muted">Reason: {d.reason}</div>}
              </td>
              <td style={{ textAlign: 'right' }}>
                {d.status === 'pending' ? (
                  <div className="row" style={{ justifyContent: 'flex-end' }}>
                    <form action={dashDose}><input type="hidden" name="id" value={d.id} /><input type="hidden" name="act" value="taken" /><button className="small">Given</button></form>
                    <form action={dashDose}><input type="hidden" name="id" value={d.id} /><input type="hidden" name="act" value="skipped" /><input type="hidden" name="reason" value="Skipped by caregiver" /><button className="ghost small">Skip</button></form>
                  </div>
                ) : (
                  <form action={dashDose}><input type="hidden" name="id" value={d.id} /><input type="hidden" name="act" value="undo" /><button className="ghost small">Undo</button></form>
                )}
              </td>
            </tr>
          ))}
        </tbody></table>
      </section>

      <section className="card" id="meds">
        <h2>Medicines</h2>
        <table><tbody>
          {((meds || []) as Med[]).map((m) => (
            <tr key={m.id}>
              <td style={{ width: 80 }}><Pill color={m.pill_color} shape={m.pill_shape} size={m.pill_size} scale={0.7} /></td>
              <td>
                <b>{m.name}</b> <span className={`tag ${m.criticality}`}>{m.criticality}</span>
                <div className="muted">{m.pattern} · {m.food} · {m.stock} left ({daysLeft(m) === Infinity ? '—' : `${daysLeft(m)} days`})</div>
                <details><summary>Edit</summary><MedForm med={m} /></details>
              </td>
              <td style={{ textAlign: 'right', width: 220 }}>
                <form action={refill} className="row" style={{ justifyContent: 'flex-end' }}>
                  <input type="hidden" name="id" value={m.id} />
                  <input name="add" type="number" min={1} defaultValue={perDay(m) * 30 || 30} style={{ width: 80 }} />
                  <button className="ghost small">+ Refill</button>
                </form>
                <form action={stopMed} style={{ marginTop: 6 }}><input type="hidden" name="id" value={m.id} /><button className="danger small">Stop medicine</button></form>
              </td>
            </tr>
          ))}
        </tbody></table>
        <details style={{ marginTop: 12 }} open={!(meds || []).length}><summary>+ Add a medicine</summary><MedForm /></details>
      </section>

      <section className="card">
        <h2>Last 7 days</h2>
        <div className="adh">
          <span />{days.map((d) => <span key={d} className="muted">{new Date(`${d}T12:00:00+05:30`).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' })}</span>)}
          {((meds || []) as Med[]).map((m) => (
            <div key={m.id} style={{ display: 'contents' }}>
              <span>{m.name.split(' ')[0]}</span>
              {days.map((d) => { const c = cell(m.id, d); return <span key={d} title={c.t} style={{ background: c.c, height: 26, borderRadius: 6 }} />; })}
            </div>
          ))}
        </div>
        <p className="muted">Green: all taken · Yellow: skipped · Red: missed · Grey: nothing due / pending</p>
      </section>

      <div className="grid">
        <section className="card">
          <h2>Doctor appointments</h2>
          {(appts || []).map((a) => (
            <div key={a.id} style={{ borderBottom: '1px solid var(--line)', padding: '8px 0' }}>
              <b>{a.doctor}</b> · {fmtDateTime(a.at)}{a.location && <div className="muted">{a.location}</div>}
              <div className="row" style={{ marginTop: 6 }}>
                <a className="btn small" href={`/visit/${a.id}`}>📋 Visit sheet</a>
                <form action={deleteAppt}><input type="hidden" name="id" value={a.id} /><button className="ghost small">Remove</button></form>
              </div>
            </div>
          ))}
          <details style={{ marginTop: 10 }}><summary>+ Add appointment</summary>
            <form action={saveAppt}>
              <label>Doctor</label><input name="doctor" placeholder="Dr. Rao, Cardiology" required />
              <label>Where</label><input name="location" placeholder="Apollo, Greams Road" />
              <div className="three"><div><label>Date</label><input name="date" type="date" required /></div><div><label>Time</label><input name="time" type="time" defaultValue="10:00" /></div><div /></div>
              <label>Questions for the doctor</label><textarea name="notes" rows={2} placeholder="Dizzy in the mornings since last week" />
              <p><button>Add appointment</button></p>
            </form>
          </details>
        </section>
        <section className="card">
          <h2>Activity</h2>
          {(acts || []).map((a) => <div key={a.id} className="muted" style={{ padding: '3px 0' }}>{fmtDateTime(a.at)} — <b>{a.actor}</b>: {a.action}</div>)}
        </section>
      </div>
    </main>
  );
}
