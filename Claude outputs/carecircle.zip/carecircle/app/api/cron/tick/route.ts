import { NextRequest, NextResponse } from 'next/server';
import { runTick } from '@/lib/tick';

export const dynamic = 'force-dynamic';

// Called every 5 minutes by Cloud Scheduler or cron-job.org with header: x-cron-secret: <CRON_SECRET>
async function handle(req: NextRequest) {
  const secret = req.headers.get('x-cron-secret') || req.nextUrl.searchParams.get('secret');
  if (!process.env.CRON_SECRET || secret !== process.env.CRON_SECRET) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const sent = await runTick();
  return NextResponse.json({ ok: true, at: new Date().toISOString(), sent });
}
export const GET = handle;
export const POST = handle;
