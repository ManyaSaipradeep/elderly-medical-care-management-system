import { notFound } from 'next/navigation';
import { db, ensureDoses, fmtTime, plainInstruction, SLOT_LABEL } from '@/lib/core';
import Kiosk from './Kiosk';

export const dynamic = 'force-dynamic';

export default async function ElderScreen({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const { data: circle } = await db.from('circles').select('*').eq('elder_token', token).maybeSingle();
  if (!circle) notFound();
  await ensureDoses(circle.id);

  const now = Date.now();
  const { data: doses } = await db.from('dose_events').select('*, medications(*)').eq('circle_id', circle.id)
    .gte('due_at', new Date(now - 6 * 3600000).toISOString()).lte('due_at', new Date(now + 24 * 3600000).toISOString()).order('due_at');

  const all = doses || [];
  // The "current" slot = the earliest still-open dose that is due within the next 60 minutes (or overdue)
  const open = all.filter((d) => d.status === 'pending' && new Date(d.due_at).getTime() <= now + 60 * 60000);
  const current = open[0];
  const slotDoses = current ? all.filter((d) => d.due_at === current.due_at) : [];
  const next = all.find((d) => d.status === 'pending' && new Date(d.due_at).getTime() > now + 60 * 60000);

  const toCard = (d: any) => ({
    id: d.id, name: d.medications.name, instr: plainInstruction(d.medications, d.qty), status: d.status,
    color: d.medications.pill_color, shape: d.medications.pill_shape, size: d.medications.pill_size,
    snoozed: !!d.snoozed_until && new Date(d.snoozed_until).getTime() > now,
  });

  return (
    <Kiosk
      token={token}
      elderName={circle.elder_name}
      slot={current ? { label: SLOT_LABEL[current.slot], time: fmtTime(current.due_at), cards: slotDoses.map(toCard) } : null}
      next={next ? `${SLOT_LABEL[next.slot]} medicines at ${fmtTime(next.due_at)}` : null}
    />
  );
}
