'use client';
import { useEffect, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import Pill from '@/components/Pill';
import { kioskAct, kioskHelp } from '@/app/actions';

type Card = { id: string; name: string; instr: string; status: string; color: string; shape: string; size: string; snoozed: boolean };
type Props = { token: string; elderName: string; slot: { label: string; time: string; cards: Card[] } | null; next: string | null };

const REASONS = ['🤢 I feel unwell', '💊 I have run out', '🙅 I do not want to take it today'];

function speak(text: string) {
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.85;
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  } catch {}
}

export default function Kiosk({ token, elderName, slot, next }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [mode, setMode] = useState<'main' | 'reasons'>('main');
  const [undo, setUndo] = useState<{ ids: string[]; msg: string } | null>(null);
  const [helpSent, setHelpSent] = useState(false);

  // Keep the screen fresh: re-check every minute
  useEffect(() => { const t = setInterval(() => router.refresh(), 60000); return () => clearInterval(t); }, [router]);
  useEffect(() => { if (!undo) return; const t = setTimeout(() => setUndo(null), 10000); return () => clearTimeout(t); }, [undo]);

  const open = slot?.cards.filter((c) => c.status === 'pending') || [];
  const act = (a: 'taken' | 'skipped' | 'snooze', reason?: string) => start(async () => {
    const ids = open.map((c) => c.id);
    for (const id of ids) await kioskAct(token, id, a, reason);
    setMode('main');
    if (a !== 'snooze') setUndo({ ids, msg: a === 'taken' ? 'Well done! Marked as taken.' : 'Okay. Your family will know why.' });
    if (a === 'taken') speak('Well done. Marked as taken.');
    router.refresh();
  });
  const doUndo = () => start(async () => { for (const id of undo!.ids) await kioskAct(token, id, 'undo'); setUndo(null); router.refresh(); });

  const readAloud = () => speak(slot && open.length
    ? `${slot.label} medicines. ${open.map((c) => c.instr).join(' ')}`
    : `All done for now. ${next ? 'Next, ' + next : ''}`);

  return (
    <main className="kiosk">
      <div className="wrap">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h1 style={{ margin: 0 }}>Hello, {elderName}</h1>
          <button className="speak" onClick={readAloud} aria-label="Read aloud">🔊 Read aloud</button>
        </div>

        {undo && (
          <div className="alert ok" style={{ fontSize: '1.3rem', marginTop: 16 }}>
            {undo.msg} <button className="ghost" style={{ marginLeft: 12 }} onClick={doUndo} disabled={pending}>Undo</button>
          </div>
        )}

        {slot && open.length > 0 && mode === 'main' && (
          <>
            <p className="slot" style={{ marginTop: 20 }}>{slot.label} · {slot.time}</p>
            {open[0].snoozed && <p className="muted">Reminder snoozed — take them when you are ready.</p>}
            {slot.cards.map((c) => (
              <div key={c.id} className={`pillcard ${c.status !== 'pending' ? 'done' : ''}`}>
                <Pill color={c.color} shape={c.shape} size={c.size} scale={1.3} />
                <div>
                  <div className="instr">{c.instr}</div>
                  <div className="name">{c.name}{c.status !== 'pending' ? ` · ${c.status}` : ''}</div>
                </div>
              </div>
            ))}
            <button className="big yes" disabled={pending} onClick={() => act('taken')}>✅ I took {open.length > 1 ? 'them' : 'it'}</button>
            <button className="big later" disabled={pending} onClick={() => act('snooze')}>⏰ Remind me in 15 minutes</button>
            <button className="big later" disabled={pending} onClick={() => setMode('reasons')} style={{ fontSize: '1.2rem', minHeight: 60, padding: 14 }}>Not today</button>
          </>
        )}

        {mode === 'reasons' && (
          <div className="reasons" style={{ marginTop: 20 }}>
            <h2 style={{ fontSize: '1.6rem' }}>Why not today?</h2>
            {REASONS.map((r) => <button key={r} disabled={pending} onClick={() => act('skipped', r.replace(/^\S+\s/, ''))}>{r}</button>)}
            <button disabled={pending} onClick={() => setMode('main')} style={{ borderStyle: 'dashed' }}>← Go back</button>
          </div>
        )}

        {(!slot || open.length === 0) && !undo && (
          <div className="pillcard" style={{ marginTop: 24, flexDirection: 'column', alignItems: 'flex-start' }}>
            <div className="instr">🌿 Nothing to take right now.</div>
            {next && <div style={{ fontSize: '1.2rem' }}>Next: {next}</div>}
          </div>
        )}

        <button className="big help" style={{ marginTop: 36 }} disabled={pending || helpSent}
          onClick={() => start(async () => { await kioskHelp(token); setHelpSent(true); speak('Your family has been told.'); })}>
          {helpSent ? '✔ Your family has been told' : '📞 Call my family'}
        </button>
      </div>
    </main>
  );
}
