import { redirect } from 'next/navigation';
import { getSession } from '@/lib/core';
import { createCircle, joinCircle } from './actions';

export const dynamic = 'force-dynamic';

const RoleSelect = () => (
  <select name="role" defaultValue="family">
    <option value="family">Family member</option>
    <option value="caretaker">Caretaker / home helper</option>
    <option value="elder">I am the elder</option>
  </select>
);

export default async function Home({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await getSession()) redirect('/dashboard');
  const { error } = await searchParams;
  return (
    <main className="wrap">
      <div className="top"><span className="brand">CareCircle</span></div>
      <h1>Amma sees one screen. The family sees everything.</h1>
      <p className="muted" style={{ fontSize: '1.05rem', maxWidth: 720 }}>
        The elder gets a single large screen: what to take now, shown as pills that look like hers.
        Family and caretakers manage the schedule, get emailed only when a dose is really missed,
        and take a ready-made visit sheet to every doctor appointment.
      </p>
      {error && <div className="alert bad">{error}</div>}
      <div className="grid">
        <form className="card" action={createCircle}>
          <h2>Start a care circle</h2>
          <label>Elder's name</label><input name="elder_name" placeholder="e.g. Lakshmi" required />
          <label>Your name</label><input name="name" placeholder="e.g. Ravi" required />
          <label>Your email (for reminders)</label><input name="email" type="email" placeholder="you@gmail.com" />
          <label>You are</label><RoleSelect />
          <label>Choose a 6-digit circle passcode</label><input name="passcode" inputMode="numeric" pattern="\d{6}" maxLength={6} placeholder="Share it only with family and caretakers" required />
          <p><button>Create circle</button></p>
        </form>
        <form className="card" action={joinCircle}>
          <h2>Join an existing circle</h2>
          <label>Circle code</label><input name="circle_code" placeholder="e.g. K7M2QX" required style={{ textTransform: 'uppercase' }} />
          <label>Passcode</label><input name="passcode" inputMode="numeric" maxLength={6} required />
          <label>Your name</label><input name="name" required />
          <label>Your email</label><input name="email" type="email" />
          <label>You are</label><RoleSelect />
          <p><button>Join circle</button></p>
        </form>
      </div>
    </main>
  );
}
