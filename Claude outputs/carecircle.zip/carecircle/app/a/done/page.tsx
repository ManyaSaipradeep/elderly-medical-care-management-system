export default async function Done({ searchParams }: { searchParams: Promise<{ ok?: string }> }) {
  const { ok } = await searchParams;
  return (
    <main className="wrap" style={{ maxWidth: 560 }}>
      <div className={`alert ${ok === '1' ? 'ok' : 'warn'}`} style={{ fontSize: '1.2rem' }}>
        {ok === '1' ? 'Recorded. Thank you — no one else will be alerted about this dose.' : 'Someone already recorded this dose. Nothing more to do.'}
      </div>
    </main>
  );
}
