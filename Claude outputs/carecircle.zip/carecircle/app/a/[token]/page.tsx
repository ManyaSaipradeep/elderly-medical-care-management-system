import { db, readToken, fmtTime, plainInstruction, SLOT_LABEL } from '@/lib/core';
import { emailAct } from '@/app/actions';

export const dynamic = 'force-dynamic';

// Opening the link only SHOWS this page. Mail scanners that pre-open links cannot log a dose:
// the dose is recorded only when a person presses the button (POST).
export default async function EmailAction({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const t = readToken<{ d: string; m: string; a: 'taken' | 'skipped' }>(token);
  const { data: d } = t ? await db.from('dose_events').select('*, medications(*), circles(elder_name)').eq('id', t.d).maybeSingle() : { data: null };
  if (!t || !d) return <main className="wrap"><div className="card"><h1>This link is not valid.</h1></div></main>;
  return (
    <main className="wrap" style={{ maxWidth: 560 }}>
      <div className="card">
        <h1>{d.circles.elder_name}'s {SLOT_LABEL[d.slot].toLowerCase()} dose</h1>
        <p style={{ fontSize: '1.15rem' }}><b>{d.medications.name}</b> · due {fmtTime(d.due_at)}<br />{plainInstruction(d.medications, d.qty)}</p>
        {d.status !== 'pending' && d.status !== 'missed' ? (
          <div className="alert ok">Already recorded as <b>{d.status}</b>{d.acted_by ? ` by ${d.acted_by}` : ''}. Nothing more to do.</div>
        ) : (
          <form action={emailAct}>
            <input type="hidden" name="token" value={token} />
            <button style={{ fontSize: '1.3rem', padding: '16px 24px', width: '100%' }}>
              {t.a === 'taken' ? '✅ Confirm: dose was given' : 'Confirm: skipped today'}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
