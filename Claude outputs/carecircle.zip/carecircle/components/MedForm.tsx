import { saveMed } from '@/app/actions';
import { PILL_COLORS } from './Pill';
import type { Med } from '@/lib/core';

export default function MedForm({ med }: { med?: Med }) {
  const p = (med?.pattern || '1-0-1').split('-');
  const t = med?.slot_times || { morning: '08:00', afternoon: '13:00', night: '21:00' };
  return (
    <form action={saveMed}>
      {med && <input type="hidden" name="id" value={med.id} />}
      <label>Medicine name</label>
      <input name="name" defaultValue={med?.name} placeholder="e.g. Amlodipine 5mg (BP)" required />

      <label>How many, when (as on the prescription, e.g. 1-0-1)</label>
      <div className="three">
        <div><span className="muted">Morning</span><input name="p_m" type="number" min={0} max={4} defaultValue={p[0] ?? 1} /><input name="t_m" type="time" defaultValue={t.morning} /></div>
        <div><span className="muted">Afternoon</span><input name="p_a" type="number" min={0} max={4} defaultValue={p[1] ?? 0} /><input name="t_a" type="time" defaultValue={t.afternoon} /></div>
        <div><span className="muted">Night</span><input name="p_n" type="number" min={0} max={4} defaultValue={p[2] ?? 1} /><input name="t_n" type="time" defaultValue={t.night} /></div>
      </div>

      <div className="three">
        <div><label>Food</label>
          <select name="food" defaultValue={med?.food || 'after food'}>
            <option>after food</option><option>before food</option><option>with food</option><option>any time</option>
          </select></div>
        <div><label>Importance</label>
          <select name="criticality" defaultValue={med?.criticality || 'normal'}>
            <option value="critical">Critical (BP, sugar, heart)</option><option value="normal">Normal</option><option value="supplement">Supplement / vitamin</option>
          </select></div>
        <div><label>Tablets in stock</label><input name="stock" type="number" min={0} defaultValue={med?.stock ?? 30} /></div>
      </div>

      <label>What the pill looks like (shown to the elder instead of the name)</label>
      <div className="three">
        <select name="pill_color" defaultValue={med?.pill_color || 'white'}>{PILL_COLORS.map((c) => <option key={c}>{c}</option>)}</select>
        <select name="pill_shape" defaultValue={med?.pill_shape || 'round'}><option>round</option><option>oval</option><option>capsule</option></select>
        <select name="pill_size" defaultValue={med?.pill_size || 'small'}><option>small</option><option>large</option></select>
      </div>
      <p><button>{med ? 'Save changes' : 'Add medicine'}</button></p>
    </form>
  );
}
