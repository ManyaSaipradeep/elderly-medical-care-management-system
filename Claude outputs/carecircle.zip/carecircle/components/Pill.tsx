const COLORS: Record<string, string> = {
  white: '#f8fafc', yellow: '#fde047', pink: '#f9a8d4', orange: '#fb923c', red: '#ef4444',
  blue: '#60a5fa', green: '#4ade80', brown: '#a16207', purple: '#c084fc',
};
export const PILL_COLORS = Object.keys(COLORS);

/** Draws the pill the way the elder sees it: colour + shape + size. */
export default function Pill({ color, shape, size = 'small', scale = 1 }: { color: string; shape: string; size?: string; scale?: number }) {
  const fill = COLORS[color] || '#e5e7eb';
  const s = (size === 'large' ? 1.25 : 1) * scale;
  const stroke = '#475569';
  if (shape === 'capsule') {
    return (
      <svg width={84 * s} height={40 * s} viewBox="0 0 84 40" aria-label={`${color} capsule`}>
        <path d="M20 2h22v36H20a18 18 0 0 1 0-36z" fill={fill} stroke={stroke} strokeWidth="2" />
        <path d="M42 2h22a18 18 0 0 1 0 36H42z" fill="#ffffff" stroke={stroke} strokeWidth="2" />
      </svg>
    );
  }
  if (shape === 'oval') {
    return (
      <svg width={72 * s} height={44 * s} viewBox="0 0 72 44" aria-label={`${color} oval tablet`}>
        <ellipse cx="36" cy="22" rx="33" ry="19" fill={fill} stroke={stroke} strokeWidth="2" />
        <line x1="36" y1="8" x2="36" y2="36" stroke={stroke} strokeOpacity=".35" strokeWidth="2" />
      </svg>
    );
  }
  return (
    <svg width={48 * s} height={48 * s} viewBox="0 0 48 48" aria-label={`${color} round tablet`}>
      <circle cx="24" cy="24" r="21" fill={fill} stroke={stroke} strokeWidth="2" />
      <line x1="10" y1="24" x2="38" y2="24" stroke={stroke} strokeOpacity=".35" strokeWidth="2" />
    </svg>
  );
}
